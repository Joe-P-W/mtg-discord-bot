# mtg-discord-bot
A bot to aid the playing of Magic the Gathering over Discord
